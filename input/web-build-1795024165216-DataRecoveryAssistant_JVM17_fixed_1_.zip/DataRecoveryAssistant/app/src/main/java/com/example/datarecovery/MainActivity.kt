package com.example.datarecovery

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.Telephony
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private val permissionRequest = 41
    private val recipient = "saw844551@gmail.com"
    private lateinit var status: TextView
    private lateinit var consent: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 40)
        }

        layout.addView(TextView(this).apply {
            text = "Data Recovery Assistant"
            textSize = 24f
        })

        layout.addView(TextView(this).apply {
            text = """

                Aplicația exportă numai SMS-urile și istoricul apelurilor disponibile pe acest telefon.

                Datele sunt pregătite local într-o arhivă ZIP. Înainte de trimitere, utilizatorul poate verifica atașamentul în aplicația de e-mail.

                Nu sunt colectate parole, tokenuri, contacte sau conversații din WhatsApp, Messenger ori alte aplicații.

                Destinatar configurat: $recipient
            """.trimIndent()
            textSize = 16f
        })

        consent = CheckBox(this).apply {
            text = "Sunt proprietarul telefonului sau am autorizarea proprietarului și sunt de acord cu exportul acestor date."
            textSize = 14f
        }
        layout.addView(consent)

        status = TextView(this).apply {
            text = "Exportul nu a început."
            textSize = 14f
        }
        layout.addView(status)

        layout.addView(Button(this).apply {
            text = "Exportă și pregătește e-mailul"
            setOnClickListener {
                if (!consent.isChecked) {
                    status.text = "Bifează confirmarea de autorizare pentru a continua."
                } else {
                    requestDataPermissions()
                }
            }
        })

        setContentView(layout)
    }

    private fun requestDataPermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_SMS)
        }
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_CALL_LOG)
        }

        if (needed.isEmpty()) exportAndShare()
        else requestPermissions(needed.toTypedArray(), permissionRequest)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            val granted = permissions.indices.all {
                grantResults.getOrNull(it) == PackageManager.PERMISSION_GRANTED
            }
            if (granted && permissions.isNotEmpty()) {
                exportAndShare()
            } else {
                status.text = "Export anulat: nu au fost acordate toate permisiunile."
            }
        }
    }

    private fun exportAndShare() {
        try {
            val smsCsv = readSms()
            val callsCsv = readCalls()
            val zipFile = File(cacheDir, "raport_telefon.zip")

            ZipOutputStream(FileOutputStream(zipFile)).use { zip ->
                addEntry(zip, "sms.csv", smsCsv)
                addEntry(zip, "istoric_apeluri.csv", callsCsv)

                val reportInfo = """
                    Raport Data Recovery Assistant
                    Generat: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}
                    Producator: ${Build.MANUFACTURER}
                    Model: ${Build.MODEL}
                    Versiune Android: ${Build.VERSION.RELEASE}

                    Arhiva conține SMS-urile și istoricul apelurilor accesibile prin permisiunile acordate.
                    Nu conține parole sau conversații din aplicații terțe.
                    Trimiterea nu este automată; utilizatorul trebuie să confirme expedierea în aplicația de e-mail.
                """.trimIndent()
                addEntry(zip, "INFORMATII.txt", reportInfo)
            }

            val uri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.provider", zipFile
            )
            val emailIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                putExtra(Intent.EXTRA_SUBJECT, "Raport date telefon")
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Atașez raportul exportat. Verifică arhiva înainte de trimitere."
                )
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            status.text = "Arhiva este pregătită. Verifică atașamentul și confirmă trimiterea."
            startActivity(Intent.createChooser(emailIntent, "Alege aplicația de e-mail"))
        } catch (e: Exception) {
            status.text = "Eroare la export: ${e.localizedMessage ?: "eroare necunoscută"}"
        }
    }

    private fun addEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun readSms(): String {
        val out = StringBuilder("data,adresa,tip,mesaj\n")
        val cursor: Cursor? = contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(
                Telephony.Sms.DATE,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.TYPE,
                Telephony.Sms.BODY
            ),
            null,
            null,
            "${Telephony.Sms.DATE} DESC"
        )

        cursor?.use {
            while (it.moveToNext()) {
                val values = listOf(
                    it.getLong(0).toString(),
                    it.getString(1) ?: "",
                    it.getInt(2).toString(),
                    it.getString(3) ?: ""
                )
                out.append(values.joinToString(",") { value -> csv(value) }).append('\n')
            }
        }
        return out.toString()
    }

    private fun readCalls(): String {
        val out = StringBuilder("data,numar,nume,durata_secunde,tip\n")
        val cursor: Cursor? = contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.DATE,
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.DURATION,
                CallLog.Calls.TYPE
            ),
            null,
            null,
            "${CallLog.Calls.DATE} DESC"
        )

        cursor?.use {
            while (it.moveToNext()) {
                val values = listOf(
                    it.getLong(0).toString(),
                    it.getString(1) ?: "",
                    it.getString(2) ?: "",
                    it.getString(3) ?: "",
                    it.getString(4) ?: ""
                )
                out.append(values.joinToString(",") { value -> csv(value) }).append('\n')
            }
        }
        return out.toString()
    }

    private fun csv(value: String): String =
        "\"" + value.replace("\"", "\"\"")
            .replace("\n", " ")
            .replace("\r", " ") + "\""
}
