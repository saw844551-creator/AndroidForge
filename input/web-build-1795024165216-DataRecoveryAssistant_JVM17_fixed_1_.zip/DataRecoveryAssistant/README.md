# Data Recovery Assistant

Proiect Android Studio (Kotlin) pentru export local, transparent și autorizat al SMS-urilor și istoricului apelurilor.

## Funcționalități
- Cere acordul explicit în interfață înainte de export.
- Cere permisiunile Android `READ_SMS` și `READ_CALL_LOG`.
- Creează local o arhivă ZIP cu SMS-uri, istoric apeluri și informații tehnice de bază.
- Deschide selectorul Android pentru aplicația de e-mail, cu `saw844551@gmail.com` precompletat.
- Utilizatorul verifică atașamentul și apasă personal butonul de trimitere. Nu există transmitere automată sau ascunsă.

## Limitări
- Nu extrage parole, tokenuri de autentificare, contacte sau mesaje din WhatsApp/Messenger.
- Conversațiile din aplicații terțe se exportă numai prin funcțiile oficiale ale aplicațiilor respective.
- Accesul la SMS și jurnalul de apeluri depinde de versiunea Android, producător și politicile dispozitivului. Unele telefoane pot restricționa aceste permisiuni pentru aplicații care nu sunt setate ca aplicație implicită relevantă.

## Compilare
1. Deschide folderul proiectului în Android Studio.
2. Așteaptă sincronizarea Gradle.
3. Alege **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Fișierul rezultat va fi în `app/build/outputs/apk/debug/app-debug.apk`.

## Cerințe
- Android Studio compatibil cu Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
